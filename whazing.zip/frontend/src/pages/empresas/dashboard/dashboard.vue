<template>
  <div class="flex justify-center" style="width: 100%;">
      <q-card class="dashboard-container-cards">
      <q-card-section class="dashboard-cards q-pa-md q-mb-sm">
        <div class="row justify-center ">

          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3': $q.dark.isActive}"
              class="my-card full-height"
            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">Versão do Sistema</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ versionStatus.currentVersion }}
                    </p>
                    <p class="my-card-text text-caption" v-if="versionStatus.status === 'updated'">
                      O sistema está atualizado
                    </p>
                    <p class="my-card-text text-caption" v-else>
                      Nova versão disponível: {{ versionStatus.newVersion }}
                    </p>
                  </div>
                  <div class="col">
                    <q-icon
                      :name="premium ? 'mdi-crown' : 'mdi-information'"
                      size="xl"
                      :color="premium ? 'gold' : '#2f2f2f'"
                      class="my-card-content"
                    />
                    <p class="my-card-text text-caption my-card-content">
                      {{ premium ? 'Versão Premium' : 'Versão Free' }}
                    </p>
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>

          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
              class="my-card full-height"

            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">Empresas cadastradas</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ quantidadeTenants }}
                    </p>
                  </div>
                  <div class="col">
                    <q-icon name="mdi-office-building" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>
          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
              class="my-card full-height"

            >
              <q-card-section class="text-center">
                    <p class="my-card-text text-caption my-card-content">Empresas Ativas</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ quantidadeTenantsActive }}
                    </p>
                  </div>
                  <div class="col">
                    <q-icon name="mdi-office-building-plus" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>
          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
              class="my-card full-height"

            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">Empresas Inativas</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ quantidadeTenants - quantidadeTenantsActive }}
                    </p>
                  </div>
                  <div class="col">
                    <q-icon name="mdi-office-building-remove" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>

          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
              class="my-card full-height"

            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">Total de Usuários</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ quantidadeUsuarios }}
                    </p>

                  </div>
                  <div class="col">
                    <q-icon name="mdi-account-multiple" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>

          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
              class="my-card full-height"
            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">Total de Contatos</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ contatos }}
                    </p>

                  </div>
                  <div class="col">
                    <q-icon name="eva-people-outline" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>

          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
              class="my-card full-height"
            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">Total de Tickets</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ tickets }}
                    </p>

                  </div>
                  <div class="col">
                    <q-icon name="mdi-ticket-outline" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>

          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
              class="my-card full-height"
            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">Total de Mensagens</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ mensagem }}
                    </p>

                  </div>
                  <div class="col">
                    <q-icon name="mdi-forum-outline" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>

          <div class="col-xs-12 col-sm-shrink">
            <q-card
              flat
              bordered
              :class="{'bg-dark color-dark3' : $q.dark.isActive}"
              class="my-card full-height"

            >
              <q-card-section class="text-center">
                <p class="my-card-text text-caption my-card-content">Total de Conexões</p>
                <div class="row items-center">
                  <div class="col">
                    <p class="my-card-number my-card-content text-h4 text-bold text-center">
                      {{ whatsapp }}
                    </p>

                  </div>
                  <div class="col">
                    <q-icon name="mdi-whatsapp" size="xl" color="#2f2f2f" class="my-card-content" />
                  </div>
                </div>
              </q-card-section>
            </q-card>
          </div>
        </div>
      </q-card-section>
    </q-card>
  </div>
</template>

<script>
import { getQuantidadeTenants, getQuantidadeTenantsActive, getMesagem, getWhatsapp, getContact, getTicket, GetVersion } from 'src/service/dashboardEmpresas'
import { getQuantidadeUsuarios } from 'src/service/user'
import { Listarp } from 'src/service/configuracoesgeneral'

export default {
  data () {
    return {
      quantidadeTenants: 0,
      quantidadeUsuarios: 0,
      quantidadeTenantsActive: 0,
      mensagem: 0,
      whatsapp: 0,
      contatos: 0,
      tickets: 0,
      premium: false,
      versionStatus: {
        status: '',
        message: '',
        currentVersion: '',
        newVersion: ''
      }
    }
  },
  methods: {
    async loadVersionp() {
      try {
        const response = await Listarp()
        this.premium = response.data.result
      } catch (error) {
        console.error('Erro ao carregar versão:', error)
      }
    },
    async loadVersion() {
      try {
        const response = await GetVersion()
        const { status, message, currentVersion, newVersion } = response.data
        this.versionStatus = {
          status: status,
          message: message,
          currentVersion: currentVersion,
          newVersion: newVersion || ''
        }
      } catch (error) {
        console.error('Erro ao carregar versão:', error)
      }
    }
  },
  mounted () {
    this.loadVersion()
    this.loadVersionp()
    getQuantidadeTenants().then(quantidade => {
      this.quantidadeTenants = quantidade
    })
    getQuantidadeUsuarios().then(response => {
      this.quantidadeUsuarios = response.data.totalUsers
    }).catch(error => {
      console.error('Erro ao obter quantidade de usuários:', error)
    })
    getQuantidadeTenantsActive().then(quantidade => {
      this.quantidadeTenantsActive = quantidade
    })
    getMesagem().then(quantidade => {
      this.mensagem = quantidade.count
    })
    getContact().then(quantidade => {
      this.contatos = quantidade.count
    })
    getTicket().then(quantidade => {
      this.tickets = quantidade.count
    })
    getWhatsapp().then(quantidade => {
      this.whatsapp = quantidade
    }
    )
  }
}
</script>

<style scoped>
</style>
