<template>
  <div v-if="userProfile === 'admin'">
    <q-table
      class="contact-table my-sticky-dynamic container-rounded-10 heightChat"
      :class="{
    'full-height': $q.screen.lt.sm
  }"
      title="Agendamentos"
      :data="agendamentos"
      :columns="columns"
      :loading="loading"
      row-key="id"
      virtual-scroll
      :virtual-scroll-item-size="48"
      :virtual-scroll-sticky-size-start="48"
      :pagination.sync="pagination"
      :rows-per-page-options="[0]"
      @virtual-scroll="onScroll"
    >
      <template v-slot:top-left>
        <div>
          <h2 :class="$q.dark.isActive ? ('color-dark3') : ''">
            <q-icon name="eva-clock-outline q-pr-sm"/>
            Agendamentos
          </h2>
          <div class="contact-header full-width">
            Data de envio:
            <DatePick dense rounded outlined label="Data Inicial Data Envio"
              class="row col"
              v-model="params.startDate"
              @input="onDateChange"
            />
            <DatePick dense rounded outlined label="Data Final Data Envio"
              class="row col"
              v-model="params.endDate"
              @input="onDateChange"
            />
            Data que foi agendado:
            <DatePick dense rounded outlined label="Data Inicial Data Agendamento"
                      class="row col"
                      v-model="params.startDateCreatedAt"
                      @input="onDateChange"
            />
            <DatePick dense rounded outlined label="Data Final Data Agendamento"
                      class="row col"
                      v-model="params.endDateCreatedAt"
                      @input="onDateChange"
            />
          </div>
        </div>
      </template>
      <template v-slot:body-cell-mediaUrl="props">
        <q-td :props="props">
          <span v-if="props.row.mediaUrl">
            <a :href="props.row.mediaUrl" target="_blank" style="text-decoration: underline; cursor: pointer;">
              Abrir Arquivo
            </a>
          </span>
          <span v-else>
            Sem Arquivo
          </span>
        </q-td>
      </template>
      <template v-slot:body-cell-ticketId="props">
        <q-td :props="props">
          <a :href="getTicketUrl(props.row.ticketId)">{{ props.row.ticketId }}</a>
        </q-td>
      </template>
      <template v-slot:body-cell-contactId="props">
        <q-td :props="props">
          {{ props.row.contactName || 'Carregando...' }}
        </q-td>
      </template>
      <template v-slot:body-cell-userId="props">
        <q-td :props="props">
          {{ formatUser(props.row.userId) }}
        </q-td>
      </template>
      <template v-slot:body-cell-createdAt="props">
        <q-td :props="props">
          {{ formatDate(props.row.createdAt) }}
        </q-td>
      </template>
      <template v-slot:body-cell-acoes="props">
        <q-td class="text-center">
          <q-btn
            flat
            round
            class="color-light1"
            :class="$q.dark.isActive ? ('color-dark1') : ''"
            icon="eva-trash-outline"
            @click="deletarMensagem(props.row)"
          />
        </q-td>
      </template>
      <template v-slot:pagination="{ pagination }">
        {{ agendamentos.length }}/{{ pagination.rowsNumber }}
      </template>
    </q-table>
  </div>
</template>

<script>
import { ListarAgendamento, DeletarMensagem } from 'src/service/tickets'
import { ListarUsuarios } from 'src/service/user'
import { ListarCores } from 'src/service/configuracoesgeneral'

export default {
  name: 'Protocolos',
  data() {
    return {
      userProfile: 'user',
      contatosCache: {},
      usuarios: [],
      agendamentos: [],
      pagination: {
        rowsPerPage: 40,
        rowsNumber: 0,
        lastIndex: 0
      },
      params: {
        pageNumber: 1,
        startDate: null,
        endDate: null,
        startDateCreatedAt: null,
        endDateCreatedAt: null,
        hasMore: true
      },
      loading: false,
      columns: [
        { name: 'body', label: 'Mensagem', field: row => row.body.substring(0, 20) + '...', align: 'left' },
        { name: 'mediaUrl', label: 'Arquivo', field: 'mediaUrl', align: 'left' },
        { name: 'ticketId', label: 'Ticket', field: 'ticketId', align: 'left' },
        { name: 'scheduleDate', label: 'Data Envio', field: 'scheduleDate', align: 'left', format: (val) => this.formatDate(val) },
        { name: 'userId', label: 'Usuário', field: 'userId', align: 'center', format: (val) => this.formatUser(val) },
        { name: 'createdAt', label: 'Data foi agendado', field: 'createdAt', align: 'center', format: (val) => this.formatDate(val) },
        { name: 'acoes', label: 'Ações', field: 'acoes', align: 'center' }
      ]
    }
  },
  methods: {
    async loadColors() {
      const root = document.documentElement

      try {
        // Chamada para o backend
        const response = await ListarCores()

        // Desestruturação dos valores retornados pela API
        const { cor1, cor2, textcor1, cor1dark, cor2dark, textcor1dark } = response.data

        // Aplicar as cores como variáveis CSS no :root
        root.style.setProperty('--q-cor1', cor1)
        root.style.setProperty('--q-cor2', cor2)
        root.style.setProperty('--q-textcor1', textcor1)
        root.style.setProperty('--q-cor1dark', cor1dark)
        root.style.setProperty('--q-cor2dark', cor2dark)
        root.style.setProperty('--q-textcor1dark', textcor1dark)
      } catch (error) {
        console.error('Erro ao carregar as cores:', error)
      }
    },
    deletarMensagem(mensagem) {
      this.$q
        .dialog({
          title: 'Atenção!! Deseja realmente deletar essa mensagem? ',
          message: 'Mensagens antigas não serão apagadas no cliente.',
          cancel: {
            label: 'Não',
            color: 'primary',
            push: true
          },
          ok: {
            label: 'Sim',
            color: 'negative',
            push: true
          },
          persistent: true
        })
        .onOk(() => {
          this.loading = true
          DeletarMensagem(mensagem)
            .then((res) => {
              this.loading = false
              mensagem.isDeleted = true
              window.location.reload()
            })
            .catch((error) => {
              this.loading = false
              console.error(error)
              this.$notificarErro('Não foi possível apagar a mensagem', error)
            })
        })
        .onCancel(() => {})
    },
    async listarUsuarios() {
      const data = await ListarUsuarios()
      this.usuarios = data.data.users
    },
    async listarAgendamentos() {
      this.loading = true
      try {
        // Tratamento para somar 1 dia às datas
        const startDate = this.params.startDate
          ? new Date(this.params.startDate).toISOString() // Converte para ISO 8601
          : null

        const endDate = this.params.endDate
          ? (() => {
            const date = new Date(this.params.endDate)
            date.setDate(date.getDate() + 1) // Soma 1 dia
            return date.toISOString() // Converte para ISO 8601
          })()
          : null

        const startDateCreatedAt = this.params.startDateCreatedAt
          ? new Date(this.params.startDateCreatedAt).toISOString()
          : null

        const endDateCreatedAt = this.params.endDateCreatedAt
          ? (() => {
            const date = new Date(this.params.endDateCreatedAt)
            date.setDate(date.getDate() + 1) // Soma 1 dia
            return date.toISOString() // Converte para ISO 8601
          })()
          : null

        const response = await ListarAgendamento({
          startDate,
          endDate,
          startDateCreatedAt,
          endDateCreatedAt,
          pageNumber: this.params.pageNumber,
          tenantId: localStorage.getItem('tenantId')
        })

        if (response.data && Array.isArray(response.data.messages)) {
          this.agendamentos = [
            ...this.agendamentos,
            ...(await Promise.all(
              response.data.messages.map(async (protocolo) => {
                return protocolo
              })
            ))
          ]
          this.pagination.rowsNumber = response.data.count || 0
          this.pagination.hasMore = response.data.hasMore
        } else {
          console.error('Resposta da API não está no formato esperado:', response.data)
        }
      } catch (error) {
        console.error('Erro ao listar agendamentos:', error)
      } finally {
        this.loading = false
      }
    },
    formatUser(userId) {
      const user = this.usuarios.find(user => user.id === userId)
      return user ? user.name : 'Usuário não encontrado'
    },
    getTicketUrl(ticketId) {
      const route = this.$router.resolve({ path: `/atendimento/${ticketId}` })
      return route.href
    },
    formatDate(dateString) {
      const date = new Date(dateString)

      // Configura o formatador de data para o fuso horário desejado (exemplo: 'America/Sao_Paulo')
      const options = {
        timeZone: 'America/Sao_Paulo', // Ajuste para o fuso horário desejado
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false // Usa o formato de 24 horas
      }

      const formatter = new Intl.DateTimeFormat('pt-BR', options)
      return formatter.format(date).replace(',', '')
    },
    async filtrarProtocolos() {
      this.params.pageNumber = 1
      this.params.hasMore = true // Garantir que há mais dados a serem carregados
      this.agendamentos = [] // Limpar agendamentos atuais para aplicar o novo filtro
      await this.listarAgendamentos()
    },
    onDateChange() {
      if (this.params.startDate && this.params.endDate) {
        this.filtrarProtocolos()
      }
      if (this.params.startDateCreatedAt && this.params.endDateCreatedAt) {
        this.filtrarProtocolos()
      }
    },
    onScroll({ to, ref, ...all }) {
      if (!this.loading && this.params.hasMore && to >= (this.agendamentos.length - 10)) {
        this.loading = true
        this.params.pageNumber++
        this.listarAgendamentos()
      }
    }
  },
  async mounted() {
    this.loadColors()
    await this.listarAgendamentos()
    await this.listarUsuarios()
    this.userProfile = localStorage.getItem('profile')
  }
}
</script>

<style lang="sass">
.my-sticky-dynamic
  /* height or max-height is important */
  height: 85vh

  .q-table__top,
  .q-table__bottom,
  thead tr:first-child th /* bg color is important for th; just specify one */
    background-color: #fff

  thead tr th
    position: sticky
    z-index: 1
  /* this will be the loading indicator */
  thead tr:last-child th
    /* height of all previous header rows */
    top: 63px
  thead tr:first-child th
    top: 0

.heightChat
  height: calc(100vh - 10px)
  .q-table__top
    padding: 8px

#tabela-contatos-atendimento
  thead
    th
      height: 55px

.blur-effect
  filter: blur(0px)
</style>
