import request from 'src/service/request'

export function ListarAgendamentoNovo(params) {
  return request({
    url: '/schedules',
    method: 'get',
    params
  })
}

export function DeletarAgendamento (data) {
  return request({
    url: `/schedules/${data.id}`,
    method: 'delete'
  })
}

export function CriarAgendamento(data) {
  return request({
    url: '/schedules/',
    method: 'post',
    data,
    timeout: 240000
  })
}
