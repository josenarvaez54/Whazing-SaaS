import { AdminListarEmpresas, AdminListarEmpresasActive, ListarWhatsappsAdmin } from 'src/service/empresas'
import { CountMensage } from 'src/service/tickets'
import request from 'src/service/request'

export async function getQuantidadeTenants () {
  try {
    const response = await AdminListarEmpresas()
    return response.data.length
  } catch (error) {
    console.error(error)
    throw error
  }
}

export async function getWhatsapp () {
  try {
    const response = await ListarWhatsappsAdmin()
    return response.data.length
  } catch (error) {
    console.error(error)
    throw error
  }
}

export async function getQuantidadeTenantsActive () {
  try {
    const response = await AdminListarEmpresasActive('active')
    return response.data.filter(item => item.status === 'active').length
  } catch (error) {
    console.error(error)
    throw error
  }
}

export async function getMesagem () {
  try {
    const response = await CountMensage()
    return response.data
  } catch (error) {
    console.error(error)
    throw error
  }
}

export function CountContact (params) {
  return request({
    url: '/count/contacts',
    method: 'get',
    params
  })
}

export async function getContact () {
  try {
    const response = await CountContact()
    return response.data
  } catch (error) {
    console.error(error)
    throw error
  }
}

export function CountTicket(params) {
  return request({
    url: '/count/tickets',
    method: 'get',
    params
  })
}

export async function getTicket () {
  try {
    const response = await CountTicket()
    return response.data
  } catch (error) {
    console.error(error)
    throw error
  }
}

export function GetVersion (params) {
  return request({
    url: '/admin/version/',
    method: 'get',
    params
  })
}
