// Este arquivo será usado com o modo "InjectManifest" no quasar.conf.js

import { precacheAndRoute } from 'workbox-precaching'
import { clientsClaim, setCacheNameDetails, skipWaiting } from 'workbox-core'
import { registerRoute } from 'workbox-routing'
import { CacheFirst } from 'workbox-strategies'

// Configuração de nomes para os caches
setCacheNameDetails({
  prefix: 'pwa',
  suffix: 'v1',
  precache: 'precache',
  runtime: 'runtime'
})

// Ativando controle imediato do service worker
clientsClaim()
skipWaiting()

// Pré-cache de arquivos essenciais
precacheAndRoute(self.__WB_MANIFEST)

// Estratégia de cache para arquivos de imagem
registerRoute(
  ({ request }) => request.destination === 'image',
  new CacheFirst({
    cacheName: 'images-cache'
  })
)

// Evento para notificações push
self.addEventListener('push', (event) => {
  if (event.data) {
    const payload = event.data.json()
    const title = payload.title || 'Nova notificação'
    const options = {
      body: payload.body || 'Você tem uma nova mensagem.',
      icon: payload.icon || '/public/whatsapp-logo.png',
      badge: payload.badge || '/public/whatsapp-logo.png',
      data: {
        url: payload.url || '/' // URL para abrir ao clicar
      }
    }

    event.waitUntil(
      self.registration.showNotification(title, options)
    )
  }
})

// Evento para clique em notificações
self.addEventListener('notificationclick', (event) => {
  event.notification.close()

  // Garante que há uma URL antes de tentar abrir
  const targetUrl = event.notification.data?.url
  if (targetUrl) {
  }
})
