<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Sms_whatsapi extends App_sms
{
    public function __construct()
    {
        parent::__construct();

        $this->add_gateway('whatsapi', [
            'name'    => 'WhatsApp API Whazing JSON',
            'info'    => '
                <p>Contatos no formato internacional sem o <b>+</b> — Ex: <b>5548999990000</b></p>
                <p>No campo <b>Mensagem</b> do trigger, cole o <b>JSON completo</b> que será enviado à API.</p>

                <hr>
                <p><strong>Variáveis disponíveis no JSON:</strong></p>
                <ul>
                    <li><code>{number}</code> — número do destinatário (somente dígitos)</li>
                    <li><code>{invoice_link}</code> — link completo da fatura (ex: <code>https://seudominio.com/invoice/28/abc123</code>)</li>
                    <li><code>{invoice_link_short}</code> — apenas o ID da fatura, sem domínio (ex: <code>28/abc123</code>). <b>Obrigatório incluir o campo auxiliar abaixo para funcionar.</b></li>
                    <li>Todas as outras merge fields padrão do PerfexCRM: <code>{contact_firstname}</code>, <code>{invoice_number}</code>, <code>{invoice_duedate}</code>, etc.</li>
                </ul>

                <hr>
                <p><strong>⚠️ Para usar <code>{invoice_link_short}</code>, adicione esta linha no JSON:</strong></p>
                <pre style="background:#f4f4f4;padding:8px;border-radius:4px;">"__link__": "{invoice_link}",</pre>
                <p>Esse campo é removido automaticamente antes do envio — a API <b>não recebe</b> esse campo, ele serve apenas para o módulo capturar o link completo e gerar a versão curta.</p>

                <hr>
                <p><strong>Exemplo — Botão com link da fatura (cta_url):</strong></p>
                <pre style="background:#f4f4f4;padding:8px;border-radius:4px;font-size:12px;">{
    "__link__": "{invoice_link}",
    "number": "{number}",
    "contents": {
        "type": "cta_url",
        "header": {
            "type": "text",
            "text": "Fatura {invoice_number}"
        },
        "body": {
            "text": "Olá {contact_firstname}, sua fatura no valor de {invoice_total} vence em {invoice_duedate}. Toque no botão abaixo para visualizá-la."
        },
        "footer": {
            "text": "Em caso de dúvidas, entre em contato."
        },
        "action": {
            "name": "cta_url",
            "parameters": {
                "display_text": "Ver Fatura",
                "url": "{invoice_link}"
            }
        }
    }
}</pre>
            ',
            'options' => [
                [
                    'name'  => 'endpoint',
                    'label' => 'URL da API',
                ],
                [
                    'name'  => 'bearer_token',
                    'label' => 'Token',
                ],
            ],
        ]);
    }

    /**
     * Remove caracteres não numéricos e zero à esquerda
     */
    private function format_phone_number($number)
    {
        $number = preg_replace('/[^0-9]/', '', $number);
        $number = ltrim($number, '0');
        return $number;
    }

    /**
     * Extrai a parte curta do invoice_link.
     * Ex: https://gestorteste.whazing.com.br/invoice/28/abc123
     *   → 28/abc123
     *
     * Padrão: tudo após /invoice/ (ou a última parte da URL se não encontrar /invoice/)
     */
    private function get_invoice_link_short($full_link)
    {
        if (empty($full_link)) {
            return '';
        }

        // Tenta extrair após /invoice/
        if (preg_match('#/invoice/(.+)$#i', $full_link, $m)) {
            return $m[1];
        }

        // Fallback: remove scheme + host, retorna o path
        $parsed = parse_url($full_link);
        return isset($parsed['path']) ? ltrim($parsed['path'], '/') : $full_link;
    }

    public function send($number, $message)
    {
        $endpoint     = $this->get_option('whatsapi', 'endpoint');
        $bearer_token = $this->get_option('whatsapi', 'bearer_token');

        $formatted_number = $this->format_phone_number($number);

        // Substitui {number} no body do template
        $body = str_replace('{number}', $formatted_number, $message);

        // Substitui {invoice_link_short}:
        // Extrai o valor do campo "__link__" que o usuário deve incluir no JSON template
        // como: "__link__": "{invoice_link}" — o Perfex substitui, nós capturamos e removemos.
        if (strpos($body, '{invoice_link_short}') !== false) {
            $full_link = '';
            if (preg_match('/"__link__"\s*:\s*"([^"]+)"/i', $body, $m)) {
                $full_link = $m[1];
            }
            $short_link = $this->get_invoice_link_short($full_link);
            // Remove o campo auxiliar do JSON final
            $body = preg_replace('/,?\s*"__link__"\s*:\s*"[^"]*"\s*,?/', '', $body);
            // Corrige vírgulas duplas ou vírgula sobrando antes de }
            $body = preg_replace('/,\s*}/', '}', $body);
            $body = str_replace('{invoice_link_short}', $short_link, $body);
        }

        $send = $this->send_raw_json($endpoint, $bearer_token, $body);

        if ($send['success']) {
            log_activity('Notificação enviada via Whatsapp para: ' . $formatted_number);
            return true;
        } else {
            log_activity($this->set_error('O envio falhou: <BR> Erro: ' . $send['message']));
            return false;
        }
    }

    /**
     * Extrai a primeira URL http(s) encontrada em uma string,
     * limpando caracteres JSON que possam estar colados no final.
     */
    private function extract_first_url($str)
    {
        // Remove qualquer tag HTML antes de buscar (caso Perfex envolva em <a href="">)
        $clean = strip_tags($str);

        // Tenta achar URL dentro de aspas JSON: "https://..."
        if (preg_match('/"(https?:\/\/[^"]+)"/i', $clean, $m)) {
            return $m[1];
        }

        // Fallback: qualquer sequência http sem espaço
        if (preg_match('#https?://[^\s"\'<>\\\\,}\]]+#i', $clean, $m)) {
            return $m[0];
        }

        return '';
    }

    /**
     * Envia o body como JSON raw diretamente para a API.
     * O body já deve ser um JSON válido (após substituição das variáveis).
     */
    public function send_raw_json($endpoint, $bearer_token, $raw_json)
    {
        // Valida se é JSON válido antes de enviar
        $decoded = json_decode($raw_json, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return [
                'success' => false,
                'message' => 'Body inválido (não é JSON): ' . json_last_error_msg() . ' | Body recebido: ' . $raw_json,
            ];
        }

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL            => $endpoint,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING       => '',
            CURLOPT_MAXREDIRS      => 10,
            CURLOPT_TIMEOUT        => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST  => 'POST',
            CURLOPT_POSTFIELDS     => json_encode($decoded), // Re-encode para garantir JSON limpo
            CURLOPT_HTTPHEADER     => array(
                'Content-Type: application/json',
                'Authorization: Bearer ' . $bearer_token,
            ),
        ));

        $response = curl_exec($curl);
        $err      = curl_error($curl);
        curl_close($curl);

        if ($err) {
            return ['success' => false, 'message' => $err];
        }

        return ['success' => true, 'message' => $response];
    }
}